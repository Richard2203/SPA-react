# HeroApp

Recuerden ejecutar en comando ```npm install``` para reconstruir los módulos de Node.

